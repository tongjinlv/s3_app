#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <error.h>
#include <string.h>
#include <fcntl.h>
#include <linux/videodev2.h>

struct matata_v4l2_control {
		__u32 	id;
		__s32	value;
		__u32	user_pt;	//add to match allwinner platform kernel struct definition
};

int fd;
const char *input_dev = "/dev/video0";
const char *qctrl_name = NULL;
int qctrl_value = 0;

struct v4l2_capability cap;
struct v4l2_queryctrl qctrl;
int main(int argc, char **argv)
{
  int ret, i;
struct matata_v4l2_control ctrl;
  

  fd = open(input_dev, O_RDWR);
  if (fd < 0) {
    perror("open video failed");
    return -1;
  }
  printf("open video '%s' success, G_CTRL = %u\n", input_dev, VIDIOC_G_CTRL);
//struct v4l2_control ctrl;

  ctrl.id = V4L2_CID_EXPOSURE;
  if (ioctl(fd, VIDIOC_G_CTRL, &ctrl) < 0) {
    perror("get ctrl failed");
    ctrl.value = -999;
  }
printf("****kevin test, ctrl.value is %u\n", ctrl.value);
return 0;
}

